
import LandingHeader from "./LandingHeader";
const Header = ({ header }) => {
       return <LandingHeader />;

};
export default Header;
